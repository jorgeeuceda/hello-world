﻿' Project : Big Bear cabins
' Author: Jorge euceda
' date : May 16, 2016
' puppose: the fallowing web application will request information for the big bear cabin computing the the cost of the number of nights 

Option Strict On
Public Class About
    Inherits Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnSumit_Click(sender As Object, e As EventArgs) Handles btnSumit.Click
        Dim decGrizzlycost As Decimal = 99D
        Dim decPolarcost As Decimal = 89D
        Dim decKodiakcost As Decimal = 79D
        Dim strName As String
        Dim strEmail As String
        Dim decCabinCost As Decimal = 0D
        Dim intNumberofNights As Integer
        Dim strMessage As String

        ' trim additional spaces that are entered by the user
        strName = txtname.Text.Trim
        strEmail = txtEmail.Text.Trim
        lblReservation.Text = ""
        If Not (chkGrizzly.Checked Or chkPolar.Checked Or chkKodiak.Checked) Then
            lblCabinError.Visible = True
            If cldArrival.SelectedDate < cldArrival.TodaysDate Then
                lblCalendarError.Visible = True
            Else
                lblCalendarError.Visible = False

            End If
        Else
            lblCabinError.Visible = False
            If cldArrival.SelectedDate >= cldArrival.TodaysDate Then
                lblCalendarError.Visible = False
                ' calculate the cost of the cabins selected by the user
                If chkGrizzly.Checked Then
                    decCabinCost += decGrizzlycost
                End If
                If chkPolar.Checked Then
                    decCabinCost += decPolarcost
                End If
                If chkKodiak.Checked Then
                    decCabinCost += decKodiakcost
                End If
                intNumberofNights = Convert.ToInt32(ddlNights.SelectedItem.Text)
                decCabinCost = intNumberofNights * decCabinCost
                strMessage = " A reservation has been made for: " & "<br>" _
                    & strName & "<br>" & "Email:" & strEmail & "<br>"
                strMessage &= "the cabins cost is: " _
                    & decCabinCost.ToString("C") & "<br>"
                strMessage &= "Arrival Date: " _
                    & cldArrival.SelectedDate.ToShortDateString() _
                    & "<br>" & " For " & intNumberofNights & " nights "
                lblReservation.Text = strMessage
            Else
                lblCalendarError.Visible = True
            End If

        End If



    End Sub
End Class